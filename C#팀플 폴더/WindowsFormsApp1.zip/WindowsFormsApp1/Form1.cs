﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApp1
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void login_Click(object sender, EventArgs e)
        {
            string userId = id_text.Text;
            string userPassword = pw_text.Text;

            if(userId.Equals("aaaa11") && userPassword.Equals("1516"))
            {
                MessageBox.Show("성공");

            }
            else
            {
                MessageBox.Show("실패\n"+"다음에 다시 도전하세요");
            }
        }
    }
}
