set serveroutput on;
create or replace trigger com
    after insert on orders
    for each row
    declare begin 
        dbms_output.put_line('��ϵ�');
    end;
